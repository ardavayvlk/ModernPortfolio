namespace ModernPortfolio.Models;

public class ErrorViewModel
{
    public string? RequestId { get; set; } 

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    /*
        int-> INTEGER YA DA SERIAL
        string-> VARCHAR TEXT
        DateTime ->  TIMESTAMP DATE
        bool -> BOOLEAN
        decimal -> DECIMAL NUMERIC
        double -> DOUBLE PRECISION
    */
}
