using System;

namespace ModernPortfolio.Models;

public class About
{
    public int Id { get; set; }
    public string Title { get; set; }=string.Empty;
    public string Description { get; set; }=string.Empty;
    public string? ImageUrl { get; set; }
    public string? Email { get; set; }
    public string? GithubUrl { get; set; }
    public string? LinkedInUrl { get; set; }
    public string? PhoneNumber { get; set; }
    public string? City { get; set; }
    public int Age { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}
