

-- About Tablosu: Hakkımda bilgilerini içerir
CREATE TABLE IF NOT EXISTS About(
    Id SERIAL PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    Description TEXT,
    Age INTEGER,
    LinkedInUrl VARCHAR(300),
    GithubUrl VARCHAR(300),
    Email VARCHAR(255),
    PhoneNumber VARCHAR(50),
    City VARCHAR(150),
    ImageUrl VARCHAR(500),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP);

-- Skills Tablosu: Yetenek bilgilerini içerir
CREATE TABLE IF NOT EXISTS Skills(
    Id SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Percentage INTEGER NOT NULL CHECK (Percentage>=0 AND Percentage<=100),
    DisplayOrder INTEGER NOT NULL DEFAULT 0,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP);

-- Projects Tablosu: Proje bilgilerini içerir
CREATE TABLE IF NOT EXISTS Projects(
    Id SERIAL PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    Description TEXT,
    ImageUrl VARCHAR(500),
    ProjectUrl VARCHAR(500),
    GithubUrl VARCHAR(500),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    IsActive BOOLEAN DEFAULT TRUE);

-- Testimonials Tablosu: Müşteri referanslarını içerir
CREATE TABLE IF NOT EXISTS Testimonials(
    Id SERIAL PRIMARY KEY,
    ClientName VARCHAR(100) NOT NULL,
    ClientPosition VARCHAR(100),
    Comment TEXT NOT NULL,
    ClientImageUrl VARCHAR(500),
    Rating INTEGER NOT NULL CHECK (Rating>=1 AND Rating<=5),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    IsActive BOOLEAN DEFAULT TRUE);

-- Contacts Tablosu: İletişim formu mesajlarını içerir
CREATE TABLE IF NOT EXISTS Contacts(
    Id SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,   
    Email VARCHAR(255) NOT NULL,   
    Subject VARCHAR(200),
    Message TEXT NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    IsRead BOOLEAN DEFAULT FALSE);

-- Users Tablosu: Kullanıcı bilgilerini içerir
CREATE TABLE
    IF NOT EXISTS Users (
        Id SERIAL PRIMARY KEY,
        UserName VARCHAR(50) NOT NULL UNIQUE,
        PasswordHash VARCHAR(255) NOT NULL,
        CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UpdatedAt TIMESTAMP);

-- Facts tablosu oluşturuluyor
CREATE TABLE
    IF NOT EXISTS Facts (
        Id SERIAL PRIMARY KEY,
        ClientsNumber INTEGER NOT NULL DEFAULT 0,
        ProjectsNumber INTEGER NOT NULL DEFAULT 0,
        HoursOfSupport INTEGER NOT NULL DEFAULT 0,
        YearsOfExperience INTEGER NOT NULL DEFAULT 0,
        CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP);


INSERT INTO About(Title, Description, ImageUrl)
VALUES ('Kelly Adams', 'Yazılım Geliştirici','ui/img/hero-bg.jpg');

INSERT INTO Skills(Name, Percentage, DisplayOrder)
VALUES
    ('HTML',90,1),
    ('CSS',95,2),
    ('ASP.NET Core Web API',85,3),
    ('ASP.NET Core MVC',85,4),
    ('React',75,5),
    ('Node',80,6);

INSERT INTO Projects(Title,Description,ImageUrl,IsActive)
VALUES
    ('Proje1','Proje1 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-1.jpg',TRUE),
    ('Proje2','Proje2 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-2.jpg',TRUE),
    ('Proje3','Proje3 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-3.jpg',TRUE),
    ('Proje4','Proje4 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-4.jpg',TRUE),
    ('Proje5','Proje5 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-5.jpg',TRUE),
    ('Proje6','Proje6 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-6.jpg',TRUE),
    ('Proje7','Proje7 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-7.jpg',TRUE),
    ('Proje8','Proje8 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-8.jpg',TRUE),
    ('Proje9','Proje9 Açıklaması','ui/img/masonry-portfolio/masonry-portfolio-9.jpg',FALSE);

INSERT INTO Testimonials(ClientName,ClientPosition,Comment,ClientImageUrl,Rating)
VALUES
    ('Client1','Client Position 1', 'Client 1 Comment','ui/img/testimonials/testimonials-1.jpg',4),
    ('Client2','Client Position 2', 'Client 2 Comment','ui/img/testimonials/testimonials-2.jpg',5),
    ('Client3','Client Position 3', 'Client 3 Comment','ui/img/testimonials/testimonials-3.jpg',4),
    ('Client4','Client Position 4', 'Client 4 Comment','ui/img/testimonials/testimonials-4.jpg',5),
    ('Client5','Client Position 5', 'Client 5 Comment','ui/img/testimonials/testimonials-5.jpg',5);

INSERT INTO
    Facts (
        ClientsNumber,
        ProjectsNumber,
        HoursOfSupport,
        YearsOfExperience
    )
VALUES
    (120, 45, 3500, 8);


-- Id = 1 olduğunu varsayarak güncelliyoruz.
UPDATE About
SET
    Age = 30,
    LinkedInUrl = 'https://www.linkedin.com/in/kellyadams',
    GithubUrl = 'https://github.com/kellyadams',
    Email = 'kelly@example.com',
    PhoneNumber = '+1 555 123 4567',
    City = 'New York',
    UpdatedAt = CURRENT_TIMESTAMP
WHERE
    Id = 1;