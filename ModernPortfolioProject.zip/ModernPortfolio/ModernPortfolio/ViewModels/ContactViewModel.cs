using System;
using System.ComponentModel.DataAnnotations;

namespace ModernPortfolio.ViewModels;

public class ContactViewModel
{
    [Required(ErrorMessage = "Ad soyad gereklidir!")]
    [Display(Name = "Ad Soyad")]
    [MinLength(5, ErrorMessage = "Ad Soyad en az 3 karakter olmalıdır!")]
    [StringLength(100, ErrorMessage = "Ad Soyad en fazla 100 karakter olabilir!")]
    public string? Name { get; set; }


    [Required(ErrorMessage = "Email adresi gereklidir!")]
    [EmailAddress(ErrorMessage = "Geçerli bir email adresi giriniz!")]
    [Display(Name = "Email")]
    public string? Email { get; set; }

    [Required(ErrorMessage = "Başlık gereklidir!")]
    [Display(Name = "Başlık")]
    [StringLength(200, ErrorMessage = "Başlık en fazla 200 karakter olabilir!")]
    public string? Subject { get; set; }

    [Required(ErrorMessage = "Mesaj gereklidir!")]
    [Display(Name = "Mesajınız")]
    [StringLength(2000, ErrorMessage = "Mesaj en fazla 2000 karakter olabilir!")]
    public string? Message { get; set; }
}
