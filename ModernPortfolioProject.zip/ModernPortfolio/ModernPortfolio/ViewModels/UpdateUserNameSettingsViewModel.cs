using System;
using System.ComponentModel.DataAnnotations;

namespace ModernPortfolio.ViewModels;

public class UpdateUserNameSettingsViewModel
{
    [Required(ErrorMessage = "Kullanıcı adı gereklidir.")]
    [Display(Name = "Kullanıcı Adı")]
    [StringLength(50, MinimumLength = 3, ErrorMessage = "Kullanıcı adının uzunluğu 3-50 karakter arasında olmalıdır.")]
    public string UserName { get; set; } = string.Empty;
}
