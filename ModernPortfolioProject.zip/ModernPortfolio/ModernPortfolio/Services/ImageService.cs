using System;

namespace ModernPortfolio.Services;

public class ImageService : IImageService
{
    private readonly IWebHostEnvironment _webHostEnvironment;

    public ImageService(IWebHostEnvironment webHostEnvironment)
    {
        _webHostEnvironment = webHostEnvironment;
    }

    public async Task DeleteImageAsync(string imageUrl)
    {
        if (string.IsNullOrEmpty(imageUrl))
        {
            return;
        }
        var filePath = Path.Combine(_webHostEnvironment.WebRootPath, "wwwroot", imageUrl);
        if (System.IO.File.Exists(filePath))
        {
            await Task.Run(() => System.IO.File.Delete(filePath));
        }

    }

    public async Task<string> SaveImageAsync(IFormFile imageFile, string folderName = "portfolio")
    {
        var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
        var fileExtension = Path.GetExtension(imageFile.FileName).ToLowerInvariant();
        if (!allowedExtensions.Contains(fileExtension))
        {
            throw new ArgumentException("Geçersiz dosya formatı. Sadece JPG, PNG ve GIF formatları desteklenir.");
        }
        if (imageFile.Length > 5 * 1024 * 1014)
        {
            throw new ArgumentException("Dosya boyutu 5MB'tan büyük olamaz.");
        }
        var fileName = $"{Guid.NewGuid()}{fileExtension}";
        var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "ui", "img", folderName);
        if (!Directory.Exists(uploadsFolder))
        {
            Directory.CreateDirectory(uploadsFolder);
        }
        var filePath = Path.Combine(uploadsFolder, fileName);
        using var stream = new FileStream(filePath, FileMode.Create);
        await imageFile.CopyToAsync(stream);
        var imageUrl = $"ui/img/{folderName}/{fileName}";
        return imageUrl;
    }
}
