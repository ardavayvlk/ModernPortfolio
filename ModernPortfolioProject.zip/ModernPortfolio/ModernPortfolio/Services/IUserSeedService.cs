using System;

namespace ModernPortfolio.Services;

public interface IUserSeedService
{
    Task SeedDefaultUserAsync();
}
