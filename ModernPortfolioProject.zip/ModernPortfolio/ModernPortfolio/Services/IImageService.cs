using System;

namespace ModernPortfolio.Services;

public interface IImageService
{
    Task<string> SaveImageAsync(IFormFile imageFile, string folderName = "portfolio");
    Task DeleteImageAsync(string imageUrl);
}
